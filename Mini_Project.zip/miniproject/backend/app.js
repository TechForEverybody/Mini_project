const express = require("express");
const path = require("path");
const mongoose = require("mongoose");
const session = require("express-session");

mongoose.connect("mongodb://localhost/himalaya_shopping", {
    useUnifiedTopology: true,
    useNewUrlParser: true,
});
let userschema = new mongoose.Schema({
    user_id: Number,
    name: String,
    email: String,
    number: Number,
    password: String,
    address: {
        type: String,
        default: null,
    },
    pincode: {
        type: Number,
        default: 0
    }
});
let productschema = new mongoose.Schema({
    pdt_id: Number,
    pdt_name: String,
    price: Number,
    type: String,
    availablity: String,
    image: String
})

let orderproductschema=new mongoose.Schema({
    order_id:Number,
    user_email:String,
    product_details:Object,
    count:Number
})



db = mongoose.connection;
db.once("open", () => {
    console.log("connected");
});
let userdetails = mongoose.model("userdetails", userschema);
let products = mongoose.model("products", productschema)
let orderdetails=mongoose.model('ordersdetaills',orderproductschema)
const app = express();
app.use(express.json())
app.use(express.urlencoded());
app.use(
    session({
        secret: "Pankajsingh",
        resave: false,
        saveUninitialized: true,
        maxAge: Date.now() + 15000
    })
);

const redirectlogin = (req, res, next) => {
    if (!req.session.useremail) {
        res.status(407).send('user is not logged in')
    } else {
        next()
    }
}
const redirecthome = (req, res, next) => {
    if (req.session.useremail) {
        res.status(403).send('bad request')
    } else {
        next()
    }
}


app.post('/authunicateuser',(req,res)=>{
    if (req.session.useremail) {
        res.status(200).send({username:req.session.username})
    }
    else{
        res.status(404).send({user:false})
    }
})

app.post("/get", (req, res) => {
    if (req.session.username) {
        console.log(req.session.username);
    }
    console.log("home requested");
    products.find({}, (err, data) => {
        res.setHeader('Content-Type', 'Application/json');
        res.status(200).send(data)
        // console.log(data);
    }).limit(7)
})
app.post('/login',redirecthome, (req, res) => {
    let entry = {
        email: req.body.email.toLowerCase(),
        password: req.body.password
    }
    userdetails.findOne({
        email: entry.email
    }, (err, data) => {
        if (data !== null) {
            if (data.password === entry.password) {
                req.session.username = data.name.split(" ")[0];
                req.session.userid = data.user_id
                req.session.useremail = data.email;
                console.log(req.session.username);
                req.session.save((err) => {
                    if (err) {
                        console.log("error on saving", err);
                    }
                })
                res.json({
                    username: data.name.split(" ")[0],
                    user_id: data.user_id
                })
            } else {
                res.status(401).send("invalid credentials")

            }
        } else {
            res.status(404).send({
                message: "user not found"
            })
        }
    })
})

app.post('/register',redirecthome, (req, res) => {
    userdetails.find().count((err, count) => {
        let entry = {
            user_id: count + 1,
            name: req.body.name.toLowerCase(),
            email: req.body.email.toLowerCase(),
            number: req.body.number,
            password: req.body.password
        }
        let userdetail = new userdetails(entry)
        userdetails.findOne({
            $or: [{
                email: entry.email
            }, {
                number: entry.number
            }]
        }, (err, data) => {
            if (data !== null) {
                res.status(409).send("done")
            } else {
                userdetail.save((err, data) => {
                    if (err) {
                        console.log(err);
                    }
                    req.session.username = data.name.split(" ")[0];
                    req.session.userid = data.user_id
                    req.session.useremail = data.email;
                    console.log(req.session.username);
                    req.session.save((err) => {
                        if (err) {
                            console.log("error on saving", err);
                        }
                    })
                    res.json({
                        username: data.name.split(" ")[0],
                        user_id: data.user_id
                    })
                })
            }
        })
    })
})


app.post('/account',redirectlogin, (req, res) => {
    userdetails.findOne({
        email:req.session.useremail
    }, (err, data) => {
            orderdetails.find({user_email:req.session.useremail},(err,orders)=>{
                res.status(200).json({userdata:data,orderdata:orders})
            })
        })
    })

app.post('/updateaddress', redirectlogin,(req, res) => {
    userdetails.updateOne({
        email: req.session.useremail
    }, {
        $set: {
            address: req.body.address,
            pincode: req.body.pincode
        }
    }, (err, data) => {
        if (err) {
            console.log(err);
        } else {
            res.status(200).send("address updated")
        }
    })
})


app.post('/logout', (req, res) => {
    req.session.destroy((err) => {
        console.log("session destroyed");
    })
    res.send('session destroyed')
})

app.listen(80, "127.0.0.1", () => {
    console.log("done go and see");
});