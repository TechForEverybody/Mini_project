import React, { createContext, useContext } from 'react'
import { useHistory } from 'react-router'
import Header from '../templates/Header'
import { userContext } from '../../App'


function Cart() {
    let { state, dispatch } = useContext(userContext)

    let history = useHistory()
    let cookie = document.cookie
    console.log(cookie);
    if (state.user === true) {
        return (
            <>  
                <Header />
            </>
        )
    }
    else {
        history.push('/login')
        return (
            <>
            </>
        )
    }

}

export default Cart
