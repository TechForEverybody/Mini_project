import React, { useContext } from 'react'
import { NavLink } from 'react-router-dom'
import '../css/main.css'
import '../css/Header.css'
import { userContext } from '../../App'


function dynamicNav(state) {
    if (state.user===true) {
        return (<li className="accountname">{state.username}
            <div className="accountoptions">
                <li><NavLink to="/account">Account</NavLink> </li>
                <li><NavLink to="/logout">Log out</NavLink></li>
            </div>
        </li>)
    }
    else {
        return (<li><NavLink to="/login">Login</NavLink></li>)
    }
}

function Header() {

    let { state } = useContext(userContext)
    return (
        <>
            <div className="header">

                <i className="fas fa-bars"></i>
                <div className="heading">
                    <h1><NavLink to="/"> <i className="fas fa-store"></i> Hmalaya Shopping </NavLink></h1>
                </div>
                <div className="searchdiv">
                    <input type="search" name="search" id="search" placeholder="Enter Here" />
                    <button><i className="fas fa-search"></i></button>
                </div>
                <div className="headerNav">
                    <li><NavLink to="/cart"><i className="fas fa-shopping-cart"></i> Cart</NavLink></li>
                    {dynamicNav(state)
                    }
                </div>
            </div>
        </>
    )
}

export default Header
