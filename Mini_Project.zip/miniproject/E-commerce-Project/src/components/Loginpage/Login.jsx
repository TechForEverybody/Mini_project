import React ,{useContext, useState} from 'react'
import Header from '../templates/Header'
import Signup from './Signup'
import Register from './Register'
import { useHistory } from 'react-router';
import { userContext } from '../../App'

function Login() {
    let { state } = useContext(userContext)
    
    let history=useHistory()
    if (state.user===true) {
        history.push('/')
    }

    let [loginform,swapforms]=useState(true);
    function formCoice() {
        if (loginform===true) {
            swapforms(false)
        }
        else{
            swapforms(true)
        }
    }
    return (
        <>
            <Header/>
            {loginform?<Signup swapform={formCoice}/>:<Register swapform={formCoice}/>}
        </>
    )
}

export default Login
