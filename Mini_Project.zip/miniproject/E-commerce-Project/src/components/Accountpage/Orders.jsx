import React from 'react'
import OrderProduct from './OrderProduct'
import '../css/Orders.css'

function Orders(object) {
    return (
        <div>
            <div className="OrdersContainer">
                {
                    object.orders.map((value,index)=>{

                        return(<OrderProduct key={index} pdtId={value.product_details.pdt_id} image={value.product_details.image} pdtname={value.product_details.pdt_name} price={value.product_details.price} count={value.count}/>)
                    })
                }
            </div>
        </div>
    )
}

export default Orders
