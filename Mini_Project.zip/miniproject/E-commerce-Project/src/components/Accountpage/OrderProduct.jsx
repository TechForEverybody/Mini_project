import React from 'react'
import { NavLink } from 'react-router-dom'
import '../css/OrderProduct.css'
function OrderProduct(object) {
    return (
        <>
            <div className="orderProductContainer">
                <div className="orderimage">
                    <img src={object.image} alt=""/>
                </div>
                <div className="orderdetails">
                        <p><NavLink to={`product/${object.pdtId}`}> {object.pdtname}</NavLink></p>
                        <p><sup>₹</sup><strong className="price">{object.price}</strong></p>
                        <p>number of items: {object.count}</p>
                    </div>
            </div>
        </>
    )
}

export default OrderProduct
