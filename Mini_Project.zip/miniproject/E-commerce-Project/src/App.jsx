import React, { createContext, useEffect, useReducer, useState } from 'react'
import { Switch, Route } from "react-router-dom";
import Home from './components/Homepage/Home'
import Login from './components/Loginpage/Login'
import Account from './components/Accountpage/Account'
import Cart from './components/Cartpage/Cart'
import Logount from './components/templates/Logount';
import Header from './components/templates/Header';
import "react-loader-spinner/dist/loader/css/react-spinner-loader.css";
import Loader from 'react-loader-spinner';

let userContext = createContext()
let homeData = createContext()



let initialState = {
  user: true,
  username: null,
}
function reducer(state, action) {
  if (action.type === "LOGIN") {
    return ({
      user: action.user,
      username: action.username
    })
  }
  else if (action.type === "LOGOUT") {
    return ({
      user: action.user,
      username: action.username
    })
  }
  return state;
}






function App() {

  let [loading, updateloading] = useState(true)




  console.log('from app.jsx');
  let [state, dispatch] = useReducer(reducer, initialState)
  let [homedata, updatehomedata] = useState([])
  async function CheckUser() {
    try {
      let response = await fetch('/authunicateuser', {
        method: "POST"
      })
      let res = await response.json()
      if (response.status === 200) {
        dispatch({ type: "LOGIN", user: true, username: res.username })
      }
      else if (response.status === 404) {
        dispatch({ type: "LOGOUT", user: false, username: null })
      }
    } catch (error) {
    }
  }
  async function getHomedata() {
    try {
      let responce = await fetch('/get',
        {
          method: "POST",
          headers: {
            "Content-Type": "Application/json"
          }
        })
      let res = await responce.json()
      updatehomedata(res)
    } catch (error) {
      console.log(error);
    }
  }
  useEffect(() => {
    CheckUser()
    getHomedata()
  }, [])
  setTimeout(() => {
    updateloading(false)
  }, 1000)
  if (loading === false) {

    return (
      <>
        <userContext.Provider value={{ state, dispatch }}>

          <Switch>
            <Route exact path="/">
              <homeData.Provider value={homedata}>
                <Home />
              </homeData.Provider>
            </Route>
            <Route exact path="/login">
              <Login />
            </Route>
            <Route exact path="/cart">
              <Cart />
            </Route>
            <Route exact path="/account">
              <Account />
            </Route>
            <Route exact path="/product/:pdt_id">
              <Header />
            </Route>
            <Route exact path="/logout">
              <Logount />
            </Route>
            <Route>
              invalid 404 page not found
        </Route>
          </Switch>
        </userContext.Provider>
      </>
    )
  } else {
    return (
      <>
        <div className="loaderContainer">
          <Loader type="Puff" color="#00BFFF" height={100} width={100} />
          <Loader type="Audio" color="#00BFFF" height={80} width={80} />
          <Loader type="BallTriangle" color="#00BFFF" height={80} width={80} />
          <Loader type="Bars" color="#00BFFF" height={80} width={80} />
          loading...
        </div>

      </>
    )
  }
}

export default App

export { userContext, homeData }
