const express = require("express");
const path = require("path");
const mongoose = require("mongoose");
const session = require("express-session");
const nodemailer = require("nodemailer");

let emailsender = nodemailer.createTransport({
    service: "Gmail",
    auth: {
        user: "himalayashoppingproject@gmail.com",
        pass: "miniprojectadmin"
    }
})

mongoose.connect("mongodb://localhost/himalaya_shopping", {
    useUnifiedTopology: true,
    useNewUrlParser: true,
});

let userschema = new mongoose.Schema({
    user_id: Number,
    name: String,
    email: String,
    number: Number,
    password: String,
    address: {
        type: String,
        default: null,
    },
    pincode: {
        type: Number,
        default: 0
    }
});

let productschema = new mongoose.Schema({
    pdt_id: Number,
    pdt_name: String,
    price: Number,
    type: String,
    availablity: String,
    image: String,
    images: Object,
    specification: Object,
    cat_id: Number,
    pro_cat_id: Number,
    Sub_cat_id: Number,
    pdt_desc: String
})

let orderproductschema = new mongoose.Schema({
    pdt_id: Number,
    product_name: String,
    image: String,
    count: Number,
    price: Number,
    deliveryStatus: {
        type: Boolean,
        default: false
    },
    paymentMode: String,
    username: String,
    useremail: String,
    useraddress: String,
    pincode: Number,
    date_of_order: {
        type: Date,
        default: Date()
    },
    date_of_delivery: {
        type: Date,
        default: null
    }
})

let cartdetailsschema = new mongoose.Schema({
    useremail: String,
    product_count: Number,
    pdt_id: Number,
    pdt_name: String,
    price: String,
    image: String
})

let admindataschema = new mongoose.Schema({
    adminemail: String,
    adminpassword: String
})

db = mongoose.connection;
db.once("open", () => {});

let userdetails = mongoose.model("userdetails", userschema);
let products = mongoose.model("products", productschema)
let orderdetails = mongoose.model('ordersdetaills', orderproductschema)
let cartdetails = mongoose.model('cartdetails', cartdetailsschema)
let admindetails = mongoose.model('admindetails', admindataschema)

const app = express();

app.use(express.json())
app.use(express.urlencoded());

app.use(
    session({
        secret: "ShivkumarChauhan",
        resave: false,
        saveUninitialized: true,
        maxAge: Date.now() + 15000
    })
);

const redirectlogin = (req, res, next) => {
    if (!req.session.useremail) {
        res.status(407).send('user is not logged in')
    } else {
        next()
    }
}
const redirecthome = (req, res, next) => {
    if (req.session.useremail) {
        res.status(403).send('bad request')
    } else {
        next()
    }
}

app.post('/authunicateuser', (req, res) => {
    if (req.session.useremail) {
        res.status(200).send({
            username: req.session.username
        })
    } else {
        res.status(404).send({
            user: false
        })
    }
})

app.post("/get", (req, res) => {
    if (req.session.username) {}
    products.find({}, (err, data) => {
        res.setHeader('Content-Type', 'Application/json');
        res.status(200).send(data)
        
    }).limit(7)
})
app.post('/login', redirecthome, (req, res) => {
    let entry = {
        email: req.body.email.toLowerCase(),
        password: req.body.password
    }
    userdetails.findOne({
        email: entry.email
    }, (err, data) => {
        if (data !== null) {
            if (data.password === entry.password) {
                req.session.username = data.name.split(" ")[0];
                req.session.userid = data.user_id
                req.session.useremail = data.email;
                req.session.save((err) => {
                    
                })
                res.json({
                    username: data.name.split(" ")[0],
                    user_id: data.user_id
                })
            } else {
                res.status(401).send("invalid credentials")
            }
        } else {
            res.status(404).send({
                message: "user not found"
            })
        }
    })
})

app.post('/register', redirecthome, (req, res) => {
    userdetails.find().count((err, count) => {
        let entry = {
            user_id: count + 1,
            name: req.body.name.toLowerCase(),
            email: req.body.email.toLowerCase(),
            number: req.body.number,
            password: req.body.password
        }
        let userdetail = new userdetails(entry)
        userdetails.findOne({
            $or: [{
                email: entry.email
            }, {
                number: entry.number
            }]
        }, (err, data) => {
            if (data !== null) {
                res.status(409).send("done")
            } else {
                userdetail.save((err, data) => {
                    
                    req.session.username = data.name.split(" ")[0];
                    req.session.userid = data.user_id
                    req.session.useremail = data.email;
                    req.session.save((err) => {
                        
                    })
                    res.json({
                        username: data.name.split(" ")[0],
                        user_id: data.user_id
                    })
                })
            }
        })
    })
})

app.post('/getproductdata', (req, res) => {
    products.findOne({
        pdt_id: req.body.product_id
    }, (err, data) => {
        if (data) {
            res.status(200).json(data)
        } else {
            res.status(403).send({
                message: "data not available"
            })
        }
    })
})

app.post('/getproductsdata', (req, res) => {
    products.find({
        pro_cat_id: req.body.product_cat_id
    }, (err, data) => {
        if (data) {
            res.status(200).json(data)
        } else {
            res.status(403).send({
                message: "data not available"
            })
        }
    })
})

app.post('/getsearchresults', (req, res) => {
    search_string = '\"' + req.body.searchText + '\"'
    products.find({
        $text: {
            $search: search_string
        }
    }, (err, data) => {
        if (data) {
            res.status(200).json(data)
        } else {
            res.status(403).send({
                message: "data not available"
            })
        }
    })
})

app.post('/addtocart', redirectlogin, (req, res) => {
    products.findOne({
        pdt_id: req.body.product_id
    }, (err, data) => {
        cartdetails.findOne({
            useremail: req.session.useremail,
            pdt_id: req.body.product_id
        }, (err, cart) => {
            if (cart === null) {
                entry = {
                    useremail: req.session.useremail,
                    product_count: 1,
                    pdt_id: data.pdt_id,
                    pdt_name: data.pdt_name,
                    price: data.price,
                    image: data.image
                }
                let cartdata = new cartdetails(entry)
                cartdata.save((err) => {
                    
                })
                res.status(200).send({
                    message: "addes to cart"
                })
            } else {
                res.status(409).send({
                    message: "product is already in the cart"
                })
            }
        })
    })
})

app.post("/getcartdata", redirectlogin, (req, res) => {
    cartdetails.find({
        useremail: req.session.useremail
    }, (err, data) => {
        if (data.length === 0) {
            res.status(404).send([])
        } else {
            res.status(200).json(data)
        }
    })
})

app.post("/deletecartitem", redirectlogin, (req, res) => {
    cartdetails.deleteOne({
        _id: req.body.item_id
    }, (err, data) => {
        if (data.deleteedCount === 1) {
            res.status(200).send({
                message: "hello"
            })
        } else {
            res.status(404).send({
                message: "not deleted"
            })
        }
    })
})

app.post('/updatecount', redirectlogin, (req, res) => {
    cartdetails.updateOne({
        _id: req.body.item_id
    }, {
        $set: {
            product_count: req.body.count
        }
    }, (err, data) => {
        res.status(200).send({
            message: "done updated count"
        })
    })
})

app.post('/account', redirectlogin, (req, res) => {
    userdetails.findOne({
        email: req.session.useremail
    }, (err, data) => {
        orderdetails.find({
            useremail: req.session.useremail
        }, (err, orders) => {
            res.status(200).json({
                userdata: data,
                orderdata: orders
            })
        }).sort({
            date_of_order: -1
        })
    })
})

app.post('/updateaddress', redirectlogin, (req, res) => {
    userdetails.updateOne({
        email: req.session.useremail
    }, {
        $set: {
            address: req.body.address,
            pincode: req.body.pincode
        }
    }, (err, data) => {
            res.status(200).send("address updated")
    })
})

app.post('/getcheckoutProductData', redirectlogin, (req, res) => {
    cartdetails.find({
        useremail: req.session.useremail
    }, (err, data) => {
        res.send(data)
    })
})

app.post('/getcheckoutaddress', redirectlogin, (req, res) => {
    userdetails.findOne({
        email: req.session.useremail
    }, (err, data) => {
        res.send(data)
    })
})

app.post('/placetheorder', redirectlogin, (req, res) => {
    cartdetails.find({
        useremail: req.session.useremail
    }, (err, data) => {
        let recieptemail = req.session.useremail
        let recieptbody = `Dear user \nYour Order details are as follows\n`
        let totalamount = 0
        let i = 1
        data.forEach((value) => {
            let entry = {
                pdt_id: value.pdt_id,
                product_name: value.pdt_name,
                image: value.image,
                count: value.product_count,
                price: value.price,
                paymentMode: req.body.paymentoption,
                username: req.body.username,
                useremail: req.session.useremail,
                useraddress: req.body.useraddress,
                pincode: req.body.userpincode,
            }
            totalamount = totalamount + entry.price * entry.count
            let orderdetail = new orderdetails(entry)
            recieptbody = recieptbody + `\n${i}) ${orderdetail.product_name}\n\tNo. of counts : ${orderdetail.count}\n\tPrice per count : ${orderdetail.price}\n\tBuyer name : ${orderdetail.username}\n\tDelivery Address : ${orderdetail.useraddress} ,${orderdetail.pincode}\n\tproduct Transaction Id : ${orderdetail._id}\n`
            orderdetail.save((error, data) => {
                if (error) {}
            })
        });
        recieptbody = recieptbody + `\nTotal Payble Amount : ${totalamount}\n\n\nThanks for using are website\nfrom Himalaya Shopping`
        let maildetails = {
            from: "himalayashoppingproject@gmail.com",
            to: recieptemail,
            subject: "Reciept of order",
            text: recieptbody
        }
        emailsender.sendMail(maildetails, (err, details) => {
        })
    })
    cartdetails.deleteMany({
        useremail: req.session.useremail
    }, (err, data) => {
        
    })
    res.status(200).send("placed")
})

app.post('/adminauthenicator', (req, res) => {
    if (req.session.admin) {
        res.status(200).send({
            message: "admin is llogged in"
        })
    } else {
        res.status(404).send({
            message: "admin is not loggged in"
        })
    }
})

function adminredirect(req, res, next) {
    if (req.session.admin) {
        next()
    } else {
        res.status(404).send({
            message: "admin is not loggged in"
        })
    }
}

app.post('/adminlogin', (req, res) => {
    admindetails.findOne({
        adminemail: req.body.adminemail.toLowerCase(),
        adminpassword: req.body.adminpassword
    }, (err, data) => {
        if (data === null) {
            res.status(404).send({
                massage: "invalid credentials"
            })
        } else {
            req.session.admin = true
            req.session.save((err) => {
                
            })
            res.status(200).send({
                message: "done"
            })
        }
    })
})

app.post('/admintobedeliveredproducts', adminredirect, (req, res) => {
    orderdetails.find({
        deliveryStatus: false
    }, (err, data) => {
        res.json(data)
    }).sort({
        date_of_order: 1
    })
})
app.post('/admindeliveredproducts', adminredirect, (req, res) => {
    orderdetails.find({
        deliveryStatus: true
    }, (err, data) => {
        res.json(data)
    }).sort({
        date_of_delivery: -1
    })
})

app.post('/gettransactiondata', adminredirect, (req, res) => {
    orderdetails.find({
        _id: req.body.pdt_transaction_id
    }, (err, data) => {
        res.json(data)
    })
})

app.post('/adminlogout', (req, res) => {
    req.session.destroy((err) => {})
    res.status(200).send({
        massage: "admin is logoutted"
    })
})

app.post('/logout', (req, res) => {
    req.session.destroy((err) => {})
    res.status(200).send('session destroyed')
})

app.listen(80, "127.0.0.1", () => {});