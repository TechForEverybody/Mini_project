// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
    apiKey: "AIzaSyApCKOPTc9R5XRCODIl-4IBUvmBjdkij4U",
    authDomain: "himalaya-shopping.firebaseapp.com",
    projectId: "himalaya-shopping",
    storageBucket: "himalaya-shopping.appspot.com",
    messagingSenderId: "1088528051347",
    appId: "1:1088528051347:web:82346a908d0162a3a53166",
    measurementId: "G-CV7QR2KT4Q",
};