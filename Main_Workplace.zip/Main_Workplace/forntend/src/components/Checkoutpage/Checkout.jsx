import React, { useContext, useEffect, useState } from 'react'
import '../css/Checkout.css'
import Header from '../templates/Header'
import Productdetails from './Productdetails'
import { checkoutContext } from '../../App'
import { useHistory } from 'react-router'
import Footer from '../templates/Footer'

function Checkout() {
    let { checkout, checkoutdispatch } = useContext(checkoutContext)
    let history = useHistory()
    let [username,updateusername]=useState()
    let [checkoutaddress, updatecheckoutadress] = useState({
        address: "",
        pincode: ""
    })

    async function getCheckoutaddress() {
        try {
            let responce = await fetch('/getcheckoutaddress', {
                method: "POST",
                headers: {
                    "Content-type": "Application/json"
                }
            })
            let res = await responce.json()
            updateusername(res.name)
            if (res.address !== null && res.pincode !== 0) {
                updatecheckoutadress({ address: res.address, pincode: res.pincode })
            }
        } catch (error) {
        }
    }

    function editAddress(event) {
        updatecheckoutadress((prevalue) => {
            return ({
                ...prevalue,
                [event.target.name]: event.target.value
            })
        })
    }

    function getcheckedValue(event) {
        let checkedvalue = document.querySelector('input[name="payment"]:checked')
        return checkedvalue.value
    }

async function placetheorder(object) {
    try {
        let response=await fetch('/placetheorder',{
            method:"POST",
            headers:{
                "Content-Type":"Application/json"
            },
            body:JSON.stringify({
                useraddress:checkoutaddress.address,
                userpincode:checkoutaddress.pincode,
                username:username,
                paymentoption:object,
            })
        })
    } catch (error) {
    }
}



    function PlaceOrder(event) {
        if (checkoutaddress.address !== "" && checkoutaddress.pincode !== "") {
            let paymentOption = getcheckedValue()
            if (paymentOption === 'Cash') {
                placetheorder(paymentOption)
                checkoutdispatch({type:"ExitCheckout",checkout:false})
                window.alert("Your Order is successfully Placed")
                history.push('/')
            }
            else {
            }

        }
        else {
            window.alert("Please fill the address feild")

        }
    }

    useEffect(() => {
        getCheckoutaddress()
    }, [])

    if (checkout.checkout === false) {
        history.push('/cart')
    }
    return (
        <>
            <Header />
            <div className="checkoutHeadings">
                <h2 style={{ textAlign: "center" }}> Order Summury </h2>
            </div>
            <div className="checkoutProducts">
                <Productdetails />
            </div>
            <div className="checkoutHeadings">
                <h2 style={{ textAlign: "center" }}> Address details </h2>
            </div>
            <div className="checkoutaddress">
                <div className="checkounteditaddress">
                    <h2 >Your Address : </h2>
                    <textarea type="text" name="address" id="address" placeholder="Enter your address" value={checkoutaddress.address} onChange={editAddress} />
                </div>
                <div className="checkounteditpincode">
                    <h2>Your pincode : </h2>
                    <input type="number" name="pincode" id="pincode" placeholder="Enter pincode" value={checkoutaddress.pincode} onChange={editAddress} />
                </div>
                <p style={{ padding: "20px" }}>Note : If you have updated your address in your account then the address field will get automatically filled else you have to enter your address</p>
            </div>
            <div className="checkoutHeadings">
                <h2 style={{ textAlign: "center" }}> Payment Option </h2>
            </div>
            <div className="deliveryOptions">
                <div className="paymentoption">
                    <div className="cash" >
                        <input type="radio" name="payment" id="cash" value="Cash" defaultChecked />
                        <label htmlFor="cash" id="cashondelivery">Cash on delivery</label>
                    </div>
                    <div className="online" >
                        <input type="radio" name="payment" id="online" value="Online" />
                        <label htmlFor="online" id="onlinepayment">Online Payment</label>
                    </div>
                </div>
                <p style={{ padding: "20px" }}>Note : By default the Cash-on-delivery is selected if you wish then change it</p>
            </div>




            <div className="placeOrder">
                <button onClick={PlaceOrder}>Place Order</button>
            </div>
            <Footer/>

        </>
    )
}

export default Checkout
