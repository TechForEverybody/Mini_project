import { NavLink } from 'react-router-dom'
import '../css/HomeProduct.css'

function HomeProduct(object) {
    return(
        <>
            <div className="homeProductcard">
                <div className="homeProductcontainer">
                    <div className="homeProductimg">
                        <img src={object.img} alt=""/>
                    </div>
                    <div className="homeProductInfo">
                        <p><NavLink to={`/product/${object.pdtId}`}> {object.productName} </NavLink></p>
                        <p><sup>₹</sup><strong className="price">{object.price}</strong></p>
                    </div>
                </div>
            </div>
        </>     
    )
}
export default HomeProduct