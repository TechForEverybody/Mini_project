import React, { useContext, useState } from 'react'
import Header from '../templates/Header'
import home from '../images/home.jpg'
import hp from '../images/logos/hp.png'
import timex from '../images/logos/timex.png'
import samsung from '../images/logos/samsung.png'
import sandisk from '../images/logos/sandisk.png'
import whirlpool from '../images/logos/whirlpool.png'
import { homeData } from '../../App'

import '../css/Home.css'
import HomeProduct from './HomeProduct'
import Footer from '../templates/Footer'
function Home() {
    let homedata = useContext(homeData)
        return (
            <>
                <Header />
                <div className="homeimg">
                    <img src={home} alt=" " />
                </div>
                <div className="homeheading">
                    <h1>Some Of Our Products</h1>
                </div>
                <div className="homeproductCollection">
                    {homedata[0] ? (<>
                        <div className="homeproducts">
                            <HomeProduct pdtId={homedata[0].pdt_id} img={homedata[0].image} productName={homedata[0].pdt_name} price={homedata[0].price} />
                            <HomeProduct pdtId={homedata[1].pdt_id} img={homedata[1].image} productName={homedata[1].pdt_name} price={homedata[1].price} />
                        </div>
                        <div className="homeproducts">
                            <HomeProduct pdtId={homedata[2].pdt_id} img={homedata[2].image} productName={homedata[2].pdt_name} price={homedata[2].price} />
                            <HomeProduct pdtId={homedata[3].pdt_id} img={homedata[3].image} productName={homedata[3].pdt_name} price={homedata[3].price} />
                            <HomeProduct pdtId={homedata[4].pdt_id} img={homedata[4].image} productName={homedata[4].pdt_name} price={homedata[4].price} />

                        </div>
                        <div className="homeproducts">
                            <HomeProduct pdtId={homedata[5].pdt_id} img={homedata[5].image} productName={homedata[5].pdt_name} price={homedata[5].price} />
                            <HomeProduct pdtId={homedata[6].pdt_id} img={homedata[6].image} productName={homedata[6].pdt_name} price={homedata[6].price} />
                        </div>
                    </>
                    ) : (<>

                    </>)}
                </div>
                <div className="dealersheading">
                    <h1>Some Of Our Dealers</h1>
                </div>
                <div className="dealersimg">
                    <div className="dealerimg">
                        <img src={hp} alt="" />
                        <img src={timex} alt="" />
                        <img src={sandisk} alt="" />
                    </div>
                    <div className="dealerimg">
                        <img src={samsung} alt="" />
                        <img src={whirlpool} alt="" />
                    </div>
                </div>
                <Footer/>
            </>
        )
    } 

export default Home
