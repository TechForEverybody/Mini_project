import React from 'react'
import { NavLink } from 'react-router-dom'
import '../css/OrderProduct.css'
function OrderProduct(object) {
    return (
        <>
            <div className="orderProductContainer">
                <div className="orderimage">
                    <img src={object.image} alt=""/>
                </div>
                <div className="orderdetails">
                        <p><NavLink to={`product/${object.pdtId}`}> {object.pdtname}</NavLink></p>
                        <p>price : <sup>₹</sup><strong className="price">{object.price}</strong></p>
                        <p>number of items: {object.count}</p>
                        <p>Date of order : {object.date_of_order.slice(0,10)}</p>
                        <p>{object.delivery_date===null?(<><span style={{color:"red"}}>Yet to be delivered</span></>):(<>Date of delivery : {object.delivery_date.slice(0,10)}</>)}</p>
                        <p>Product Transaction ID : {object.transaction_id}</p>
                    </div>
            </div>
        </>
    )
}

export default OrderProduct
