import React from 'react'
import OrderProduct from './OrderProduct'
import '../css/Orders.css'

function Orders(object) {
    return (
        <>{object.orders.length>0?(
            <div className="OrdersContainer">
            {
                object.orders.map((value,index)=>{

                    return(<OrderProduct key={index} pdtId={value.pdt_id} image={value.image} pdtname={value.product_name} price={value.price} count={value.count} date_of_order={value.date_of_order} delivery_date={value.date_of_delivery} transaction_id={value._id}/>)
                })
            }
        </div>
        ):(
            <div className="notorderedyet">
                <div>👜 You haven`t Ordered any product yet 👜</div>
                <div>(❁´◡`❁)</div>
            </div>
        )}
        </>
    )
}

export default Orders
