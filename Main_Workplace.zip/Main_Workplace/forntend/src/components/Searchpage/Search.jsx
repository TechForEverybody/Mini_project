import React, { useEffect, useState } from 'react'
import { useParams } from 'react-router'
import Header from '../templates/Header'
import ProductLayout from './ProductLayout'
import '../css/Products.css'
import Loader from 'react-loader-spinner'
import Footer from '../templates/Footer'

function Search() {
    let [notdata,updatedatastatus]=useState(false)
    let { search_text } = useParams()
    let [searchText,updatecatId]=useState(search_text)
    let [pdtsData, updatePdtData] = useState(null)
    async function getData(object) {
        try {
            let response = await fetch('/getsearchresults', {
                method: "POST",
                headers: {
                    "Content-Type": "Application/json"
                },
                body: JSON.stringify({
                    searchText: searchText
                })
            })
            let data = await response.json();
            if (response.status === 200) {
                updatePdtData(data)
            }
            if (data.length!==0) {
                updatedatastatus(false)
            }
            else{
                updatedatastatus(true)
            }
        } catch (error) {
        }
    }
    useEffect(() => {
        getData()
        updatecatId(search_text)
    }, [search_text,searchText])

    return (
        <>
            <Header/>
            <div className="searchString">
                <h2 style={{textAlign:"center"}}>results for <span style={{color:"coral"}}>"{searchText}"</span> </h2>
            </div>
                
            {(pdtsData!==null)?( (notdata===false)? (
            <div className="productscontainer">
                <div className="ProductsContainer">
                {pdtsData.map((value,index)=>{
                    return <ProductLayout pdtId={value.pdt_id} pdtImage={value.image} pdtPrice={value.price} pdtName={value.pdt_name} />
                })}
            </div>
            </div>
            ):(<> 
            <div className="ProductsDataNotFound">
                <span>🛒Sorry , Data not found 🛒</span>
                <span>🛒Please try with other keyword 🛒</span>
            </div>            
            </>)):(<>
                <div className="loaderContainer">
                    <Loader type="Puff" color="#00BFFF" height={100} width={100} />
                    <Loader type="Audio" color="#00BFFF" height={80} width={80} />
                    <Loader type="BallTriangle" color="#00BFFF" height={80} width={80} />
                    <Loader type="Bars" color="#00BFFF" height={80} width={80} />
                    loading...
                </div>
            </>)}
            <Footer/>
        </>
    )
}

export default Search
