import React from 'react'
import '../css/Footer.css'
function Footer() {
    return (
        <>
            <footer className="footer">
                <div className="imformationforms">
                    <div>
                    <span>Connect With Us</span>
                        <a href="https://docs.google.com/forms/d/e/1FAIpQLSesSxMK036Y4O96WDQm036HzJZEsNlvrDWHHR47p69ghgKgCg/viewform" target="__blank">Give Suggestions</a>
                        <a href="https://docs.google.com/forms/d/e/1FAIpQLSdzBv0--sjNbdfKVD8nS1vpA5JxGXmbSOl8ym4W69U7gILEkw/viewform" target="__blank">Register Complaint</a>
                    </div>
                    <div className="contactdetails">
                        <span> Contact Us  </span><div>Email : himalayashoppingproject@gmail.com <br />Number : +919999999999 </div>
                    </div>
                </div>
                <div className="footername">
                    Pillai College of Engineering
                </div>
            </footer>
        </>
    )
}

export default Footer
